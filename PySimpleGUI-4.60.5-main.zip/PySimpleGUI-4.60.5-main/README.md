# PySimpleGUI-4.60.5
PySimpleGUI/4.60.5 files

windows install

py -m pip install --no-index --find-links=file:///local/dir/ SomeProject

py -m pip install --no-index --find-links=/local/dir/ SomeProject

py -m pip install --no-index --find-links=relative/dir/ SomeProject

linux install

python3 -m pip install --no-index --find-links=file:///local/dir/ SomeProject

python3 -m pip install --no-index --find-links=/local/dir/ SomeProject

python3 -m pip install --no-index --find-links=relative/dir/ SomeProject

